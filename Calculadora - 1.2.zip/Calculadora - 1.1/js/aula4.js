function soma() {
    let coisa1 = Number(document.getElementById('v1').value);
    let coisa2 = Number(document.getElementById('v2').value);

    let resultado = coisa1 + coisa2;
    document.writeln(resultado + '<br><br>');

    const voltar = document.createElement("button");
    voltar.innerText = "Voltar";
    document.body.appendChild(voltar);
    voltar.onclick = function () {
        reload();
    }
}
function sub() {
    let coisa1 = Number(document.getElementById('v1').value);
    let coisa2 = Number(document.getElementById('v2').value);

    let resultado = coisa1 - coisa2;
    document.writeln(resultado + '<br><br>');

    const voltar = document.createElement("button");
    voltar.innerText = "Voltar";
    document.body.appendChild(voltar);
    voltar.onclick = function () {
        reload();
    }
}
function multi() {
    let coisa1 = Number(document.getElementById('v1').value);
    let coisa2 = Number(document.getElementById('v2').value);

    let resultado = coisa1 * coisa2;
    document.writeln(resultado + '<br><br>');

    const voltar = document.createElement("button");
    voltar.innerText = "Voltar";
    document.body.appendChild(voltar);
    voltar.onclick = function () {
        reload();
    }
}
function div() {
    let coisa1 = Number(document.getElementById('v1').value);
    let coisa2 = Number(document.getElementById('v2').value);

    let resultado = coisa1 / coisa2;
    if (coisa1 = 0) {
        document.writeln('0');
    }
    if (isFinite(resultado)) {
        document.writeln('Nenhum número é divisível por 0');
    }
    document.writeln(resultado + '<br><br>');

    const voltar = document.createElement("button");
    voltar.innerText = "Voltar";
    document.body.appendChild(voltar);
    voltar.onclick = function () {
        reload();
    }
}
function reload(){
    window.location.reload();
}