//Atividade 1
alert("Oie migo qual aquela música que a gente não para de cantar mesmo?")

function msg() {
    //Atividade 2 
    alert("Oi Emerson.");
}

function limonations() {
    //Atividade 3.1
    document.getElementById("demo").innerHTML = "Limonations";
}
function megalimonation() {
    document.getElementById("demo").innerHTML = "Meu suco favorito é...<b>(usando GetById)</b>";
}

function Tagn() {
    tg = document.getElementsByTagName("p");
    tg[1].innerHTML = "Usando TagName"
}
function Classn() {
    cn = document.getElementsByClassName("ClassN");
    cn[0].innerHTML = "Usando Class";
}

function query1() {  
    document.querySelector("p.coisa").style.color = "crimson";
}

function queryall() {
    let qall = document.querySelectorAll("p.coisa");
    qall[0].style.color = "blue"
    qall[1].style.color = "blue";
}

function foco() {
    empute = document.getElementById("focu")
    empute.style.backgroundColor = "crimson";
}

function sucao(){
    var suco = document.getElementById("susso").value;
    document.getElementById("demo2").innerHTML = "Você escolheu suco de " + suco;
}

function ratito(){
    document.getElementById("ratono").src = "https://img.freepik.com/fotos-premium/rato-morto-fundo-na-estrada_71818-80.jpg";
}
function mortito(){
    document.getElementById("ratono").src = "https://img.freepik.com/fotos-premium/rato-branco-vivo-fofo_325774-3206.jpg";
}
