//Atividade 1
alert("Oie migo qual aquela música que a gente não para de cantar mesmo?")

function msg() {
    //Atividade 2 
    alert("Oi Emerson.");
}

function limonations() {
    //Atividade 3.1
    document.getElementById("demo").innerHTML = "Limonations";
}
function megalimonation() {
    document.getElementById("demo").innerHTML = "Meu suco favorito é...";
}

function Tagn() {
    tg = document.getElementsByTagName("p");
    tg[1].innerHTML = "Usando TagName"
}
function Classn() {
    cn = document.getElementsByClassName("ClassN");
    cn[0].innerHTML = "Usando class";
}

function query1() {  
    document.querySelector("p.coisa").style.color = "crimson";
}

function queryall() {
    let qall = document.querySelectorAll("p.coisa");
    qall[0].style.color = "green"
    qall[1].style.color = "green";
}


    



